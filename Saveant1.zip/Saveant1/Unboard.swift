//
//  Unboard.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 28/01/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit

class Ubboard: SKSpriteNode
{
    
}
