//
//  Leaf.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 17/12/1441 AH.
//  Copyright © 1441 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit
enum LeafSettings
{
    static let leafDistance: CGFloat = 16
    static let leafSpeed: CGFloat = 80.0
}
class Leaf: SKSpriteNode,EventListenerNode
{
    
    let POINTS_PER_SEC: CGFloat = 350.0
    var wayPoints: [CGPoint] = []
    var velocity = CGPoint(x: 0, y: 0)
    static let kLeafappedNotification = "kLeafTappedNotification"
    var hasPassenger = false
    init()
    {
        let texture = SKTexture(pixelImageNamed: "leaf-2")
        super.init(texture: texture, color: .white,
                   size: texture.size())
        
        name = "Leafy"
        zPosition = 50
        
        physicsBody = SKPhysicsBody(circleOfRadius: size.width/6)
        physicsBody?.affectedByGravity = false
        setScale(0.38)
        physicsBody?.categoryBitMask = PhysicsCategory.Leaf
        physicsBody?.contactTestBitMask = PhysicsCategory.Sand
        physicsBody?.collisionBitMask = PhysicsCategory.Sand
        
        physicsBody?.restitution = 0
        physicsBody?.allowsRotation = false
        
        
    }
    
    func postNotification() {
          NotificationCenter.default.post(name: NSNotification.Name(Leaf.kLeafappedNotification), object: nil)
    }
    
    func didMoveToScene()
    {
        //isUserInteractionEnabled = true
    }
    //When touch recieved in gamescene , take it then pass it to move th leaf

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        super.touchesBegan(touches, with: event)
        guard let touch = touches.first else { return }
 
     }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesBegan(touches, with: event)
        guard let touch = touches.first else { return }
        
        let touchLocation = touch.location(in: parent!)
        clearWayPoints()
        addMovingPoint(point: touchLocation)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>,
                               with event: UIEvent?)
    {
        super.touchesMoved(touches, with: event)
        guard let touch = touches.first else {
            return
        }
        
        let touchLocation = touch.location(in: parent!)
        addMovingPoint(point: touchLocation)
        
    }
    
    func addMovingPoint(point: CGPoint) {
        wayPoints.append(point)
    }
    
    func move(dt: TimeInterval)
    {
        let currentPosition = position
        var newPosition = position
        
        //1
        if wayPoints.count > 0
        {
            let targetPoint = wayPoints[0]
            
            //1
            let offset = CGPoint(x: targetPoint.x - currentPosition.x, y: targetPoint.y - currentPosition.y)
            let length = Double(sqrtf(Float(offset.x * offset.x) + Float(offset.y * offset.y)))
            let direction = CGPoint(x:CGFloat(offset.x) / CGFloat(length), y: CGFloat(offset.y) / CGFloat(length))
            velocity = CGPoint(x: direction.x * POINTS_PER_SEC, y: direction.y * POINTS_PER_SEC)
            
            //2
            newPosition = CGPoint(x:currentPosition.x + velocity.x * CGFloat(dt), y:currentPosition.y + velocity.y * CGFloat(dt))
            position = newPosition
            
            
            //3
            if frame.contains(targetPoint) {
                wayPoints.remove(at: 0)
            }
            else {
                newPosition = CGPoint(x: currentPosition.x + velocity.x * CGFloat(dt),
                                      y: currentPosition.y + velocity.y * CGFloat(dt))
                position = newPosition
            }
        }
     //   zRotation = atan2(velocity.y, velocity.x)
        
    }
    
    
    
    func clearWayPoints() {
        wayPoints.removeAll(keepingCapacity: false)
    }
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

import SpriteKit

extension SKTexture {
    convenience init(pixelImageNamed: String) {
        self.init(imageNamed: pixelImageNamed)
        self.filteringMode = .nearest
    }
}
