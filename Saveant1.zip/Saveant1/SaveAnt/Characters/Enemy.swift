//
//  Enemy.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 26/02/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import GameplayKit
import SpriteKit
enum EnemySettings {
  static let enemyDistance: CGFloat = 16
}
class Enemy : SKSpriteNode
{
    
    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    var POINTS_PER_SEC: CGFloat = 50
    let speedUp : CGFloat = 480.0
    var wayPoints: [CGPoint] = []
    var velocity = CGPoint(x: 0, y: 0)
    var isSafe = false
    var isSpeeding = false
     private var hookNode = SKSpriteNode(imageNamed: "hook")
     var isOnEdge = false
    var isEnemyOnStand = true
    var enemyAreaLocation = CGPoint()
    var starLocation = CGPoint()
    var dt : TimeInterval = 0.0
    let degreesToRadians = CGFloat.pi / 180
    var onReturn = false
    var moveAgain = SKAction()
    var moveBy =  SKAction()
    let targetPoint = CGPoint(x: 120, y:150)
    var foundOne  = false
    {
        didSet{
            if foundOne == false
            {
                 self.moveBug()
            }
         }
    }
 
    init()
    {
        let texture = SKTexture(pixelImageNamed: "antH")
        super.init(texture: texture, color: .white,
                   size: texture.size())
        name = "enemy"
        zPosition = 60
         physicsBody = SKPhysicsBody(circleOfRadius:size.width/12)
        physicsBody?.categoryBitMask = PhysicsCategory.Enemy
 
        physicsBody?.collisionBitMask = PhysicsCategory.Water
        physicsBody?.contactTestBitMask = PhysicsCategory.Ant |   PhysicsCategory.Water
        setScale(0.23)
        physicsBody?.restitution = 0
        physicsBody?.allowsRotation = true
        physicsBody?.isDynamic = true
     }
    
    func didMoveToScene()
    {
        isUserInteractionEnabled = true
        
    }
    
    func addMovingPoint(point: CGPoint)
    {
        wayPoints.append(point)
    }
    
    @objc func moveBugRandomly() {
      // 1
      let randomX = CGFloat(Int.random(min: -1, max: 1))
      let randomY = CGFloat(Int.random(min: -1, max: 1))
      
        let vector = CGVector(dx: randomX * 16.0,
                              dy: randomY * 16.0)
      // 2
      let moveBy = SKAction.move(by: vector, duration: 1)
      let moveAgain = SKAction.perform(#selector(moveBug),
                                       onTarget: self)
      
      // 1
//      let direction = animationDirection(for: vector)
      // 2
//      if direction == .left {
//        xScale = abs(xScale)
//      } else if direction == .right {
//        xScale = -abs(xScale)
//      }
      // 3
//      run(animations[direction.rawValue], withKey: "animation")
      run(SKAction.sequence([moveBy, moveAgain]))
    }
    
    
    func die() {
      // 1
      removeAllActions()
      texture = SKTexture(pixelImageNamed: "bug_lt1")
      yScale = -1
      // 2
      physicsBody = nil
      // 3
      run(SKAction.sequence([SKAction.fadeOut(withDuration: 3),
                             SKAction.removeFromParent()]))
    }
    func move(dt: TimeInterval)
    {
        let currentPosition = position
        var newPosition = position
 
        if wayPoints.count > 0
        {
             if isSpeeding == true
            {
                POINTS_PER_SEC = speedUp
             }
            else {
                POINTS_PER_SEC = 80.0
            }
 
            let targetPoint = wayPoints[0]
             //1
            let offset = CGPoint(x: targetPoint.x - currentPosition.x , y: targetPoint.y - currentPosition.y )
            let length = Double(sqrtf(Float(offset.x * offset.x) + Float(offset.y * offset.y)))
            let direction = CGPoint(x:CGFloat(offset.x) / CGFloat(length), y: CGFloat(offset.y) / CGFloat(length))
            velocity = CGPoint(x: direction.x * POINTS_PER_SEC, y: direction.y * POINTS_PER_SEC)
            
            //2
            newPosition = CGPoint(x:currentPosition.x + velocity.x * CGFloat(dt), y:currentPosition.y + velocity.y * CGFloat(dt))
            position = newPosition
 
            //3
            if frame.contains(targetPoint)
            {
                 wayPoints.remove(at: 0)
            }
            else {
                newPosition = CGPoint(x: currentPosition.x + velocity.x * CGFloat(dt),
                                      y: currentPosition.y + velocity.y * CGFloat(dt))
              
                position = newPosition
            }
        }
        zRotation = atan2(velocity.y, velocity.x)
 
    }
 
    
    @objc func moveBug()
    {
         if foundOne == true
        {
            return
        }
 
        if Float(position.x) <= Float(targetPoint.x)
        {
          zRotation = -.pi/4
            let moveBack = SKAction.move(to: starLocation, duration: 4.0)
         run( moveBack) { [self] in
            
              run(moveAgain)
          }
           }
        else
         {
             let currentPosition = position
            var newPosition = position
        let offset = CGPoint(x: targetPoint.x - currentPosition.x , y: targetPoint.y - currentPosition.y )
        
        let length = Double(sqrtf(Float(offset.x * offset.x) + Float(offset.y * offset.y)))
        
        let direction = CGPoint(x:CGFloat(offset.x) / CGFloat(length), y: CGFloat(offset.y) / CGFloat(length))
        
        velocity = CGPoint(x: direction.x * 30, y: direction.y * 30)
        
  
            newPosition = CGPoint(x:currentPosition.x + velocity.x * CGFloat(dt), y:currentPosition.y + velocity.y * CGFloat(dt))
        position = newPosition
        zRotation = atan2(velocity.y, velocity.x)
 
             moveBy = SKAction.move(to: newPosition, duration: 0.0001)
            
       moveAgain = SKAction.perform(#selector(moveBug),
                                       onTarget: self)
         run(SKAction.sequence([moveBy, moveAgain]))
          }
        
        
    }
 
 
    func interact()
    {
         isUserInteractionEnabled = false
     }
    
    
    func clearWayPoints() {
        wayPoints.removeAll(keepingCapacity: false)
    }
}
