//
//  Ant.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 17/12/1441 AH.
//  Copyright © 1441 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit
enum PlayerSettings {
  static let playerSpeed: CGFloat = 280.0
}
class Ant: SKSpriteNode, EventListenerNode, InteractiveNode
{
    
    var wayPoints :[CGPoint] = []
   var velocity = CGPoint(x: 0, y: 0)
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
//        velocity = aDecoder.decodeCGPoint(
//            forKey: "Ant.velocity")
      //   wayPoints = aDecoder.decodeObject(
         //   forKey: "Ant.wayPoints") as! [CGPoint]
        
        print("waypoints = \(wayPoints.first)")
 
       // fatalError("init(coder:) has not been implemented")
    }
 
 
     init()
    {
        let texture = SKTexture(pixelImageNamed: "antH")
        super.init(texture: texture, color: .white,
                   size: texture.size())
        name = "HeroAnt"
        zPosition = 60
        physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: 80, height: 80))
        physicsBody?.categoryBitMask = PhysicsCategory.Ant
//        physicsBody?.collisionBitMask =
//            PhysicsCategory.Grass
        physicsBody?.contactTestBitMask = PhysicsCategory.Leaf  | PhysicsCategory.Sand | PhysicsCategory.Collectables | PhysicsCategory.Water
        setScale(0.23)
        physicsBody?.restitution = 0
        physicsBody?.allowsRotation = false
        physicsBody?.isDynamic = true
        //         createAnimations(character: "bug")
    }
    
    func didMoveToScene()
    {
        isUserInteractionEnabled = true
        
    }
    
    func addMovingPoint(point: CGPoint)
    {
        wayPoints.append(point)
    }
    
 
    func move(dt: TimeInterval)
    {
         
        let currentPosition = position
        var newPosition = position
        
        //1
//        print("ant with name \(name) is on move and have points count \(wayPoints.count)")
        if wayPoints.count > 0
        {
 
//            print("ant with name \(name) is on move and have points count \(wayPoints.count)")
            //Way points is just for dragging, in my case it will only count always 1 point.
            let targetPoint = wayPoints[0]
             //1
            let offset = CGPoint(x: targetPoint.x - currentPosition.x , y: targetPoint.y - currentPosition.y )
            let length = Double(sqrtf(Float(offset.x * offset.x) + Float(offset.y * offset.y)))
            let direction = CGPoint(x:CGFloat(offset.x) / CGFloat(length), y: CGFloat(offset.y) / CGFloat(length))
            velocity = CGPoint(x: direction.x *  PlayerSettings.playerSpeed, y: direction.y *  PlayerSettings.playerSpeed)
            
            //2
            newPosition = CGPoint(x:currentPosition.x + velocity.x * CGFloat(dt), y:currentPosition.y + velocity.y * CGFloat(dt))
            position = newPosition
 
            //3
            if frame.contains(targetPoint)
            {
                print(" Frame contains")
                 wayPoints.remove(at: 0)
            }
            else {
               
                newPosition = CGPoint(x: currentPosition.x + velocity.x * CGFloat(dt),
                                      y: currentPosition.y + velocity.y * CGFloat(dt))
                 position = newPosition
            }
        }
        zRotation = atan2(velocity.y, velocity.x)
 
    }
 
    
    func interact()
    {
         isUserInteractionEnabled = false
     }
 
    
    
    

    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        super.touchesBegan(touches, with: event)
               guard let touch = touches.first else
               { return }
                 let touchLocation =  touch.location(in: parent!)
 
               clearWayPoints()
               addMovingPoint(point: touchLocation)
  
      }
    
      override func touchesMoved(_ touches: Set<UITouch>,
              with event: UIEvent?)
       {
            super.touchesMoved(touches, with: event)
             guard let touch = touches.first else {
                return
              }
                   let touchLocation = touch.location(in: parent!)
  //        clearWayPoints()
               addMovingPoint(point: touchLocation)
    
           }
    
    var touchCount = 0
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        super.touchesEnded(touches, with: event)
        guard let touch = touches.first else {
           return
         }
         let touchLocation = touch.location(in: parent!)
     }
    
    
    
    func clearWayPoints() {
        wayPoints.removeAll(keepingCapacity: false)
    }
    
    override func encode(with aCoder: NSCoder)
    {
      aCoder.encode(wayPoints, forKey: "Ant.wayPoints")
      aCoder.encode(velocity, forKey: "Ant.velocity")
      super.encode(with: aCoder)
    }
}
