//
//  Sand.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 29/12/1441 AH.
//  Copyright © 1441 Ahmed Sabir. All rights reserved.
//

import SpriteKit
class Stuff:  SKSpriteNode, EventListenerNode, InteractiveNode
{
    //Click button
    //show load
    //pick one to drope
    //remove the others from parent scene
    var dropLocation = CGPoint()
    var stuffArray = [Stuff]()
    var isTaken = false
    var haveInstruction = false
    static let kStuffTappedNotification = "kStuffTappedNotification"
    lazy  var removedStuff = Stuff()
    var removedStuffInfo = [String:Stuff]()
     func didMoveToScene()
    {
        isUserInteractionEnabled = true
    }
    
    func interact()
    {
    }
   
    //Remove the selected stuff from menu and add it to the scene
    func throwSelected(named:String)
    {
       print("Tryng to through item")
         for (i, stuff)in SingletonClass.sharedInstance.stuffArry.enumerated() {
            
            if stuff.name == named
            {
                removedStuffInfo["name"] = stuff
                   removedStuff = SingletonClass.sharedInstance.stuffArry.remove(at: i)
                removedStuff.removeFromParent()
 
                NotificationCenter.default.post(name: NSNotification.Name(Stuff.kStuffTappedNotification), object: nil, userInfo: removedStuffInfo)
             }
            else {
                
                stuff.removeFromParent()
            }
        }
 
        
    }
    
 
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        print("Trying to throw")
         super.touchesEnded(touches, with: event)
                guard let touch = touches.first else { return }
          
         throwSelected(named:(parent?.nodes(at: touch.location(in: parent!)).first?.name)!)
    }
    
    
}
