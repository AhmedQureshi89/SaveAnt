//
//  StuffAnalogContorller.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 14/01/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit
struct StuffTypes
{
    static let Seed : String = "appleSeed"
    static let Food:String = "food"
    static let Liqued:String = "liquid"
}
class StuffAnalogContorller: SKSpriteNode, EventListenerNode, InteractiveNode
{
    var stuffDictionary = [ Stuff(imageNamed:"appleSeed"), Stuff(imageNamed:"foodW"), Stuff(imageNamed:"liquid")]
    var nameArray = ["appleSeed","foodW","liquid"]
    var factor = CGPoint(x: 0.2, y: 0.8)
    var stuff:Stuff!
    var accmulateDistance = 100
    var isStuffMenuShwon = false
    
     var isSeedTaken = false
    
    init()
    {
        let texture = SKTexture(pixelImageNamed: "jStick")
        super.init(texture: texture, color: .white,
                   size: texture.size())
        name = "stuffController"
        //zPosition = 60
        //physicsBody = SKPhysicsBody(circleOfRadius:size.width/9)
   
     }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func didMoveToScene()
    {
            isUserInteractionEnabled = true
        NotificationCenter.default.addObserver(
        self, selector: #selector(toggleShow), name: Notification
          .Name(Stuff.kStuffTappedNotification), object:nil )
    }
    
    
    @objc func toggleShow()
    {
        isStuffMenuShwon = !isStuffMenuShwon
    }
    //Shows the menu of stuff collected on the left side
    func interact()
    {
        for (_,stuff) in SingletonClass.sharedInstance.stuffArry.enumerated()
        {
            
            self.stuff = stuff
            self.stuff.setScale(0.30)
             
             self.stuff.didMoveToScene()
            let dropLocatio = CGPoint(x:  (self.frame.size.width) * -0.5 + CGFloat(4) , y:  (self.frame.size.height) * -0.5 + CGFloat(accmulateDistance)  )
            self.stuff.position = dropLocatio
            
            addChild(self.stuff)
            accmulateDistance += 100
        }
 
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
//        super.touchesEnded(touches, with: event)
        //guard let touch = touches.first else { return }
        
         if !SingletonClass.sharedInstance.stuffArry.isEmpty && isStuffMenuShwon == false
         {
             interact()
            isStuffMenuShwon = !isStuffMenuShwon
        }
        else {
           return
        }
       
        
            
    }
    
}

class SingletonClass {
    static let sharedInstance = SingletonClass()
    var stuffArry = [Stuff]()
    
}
