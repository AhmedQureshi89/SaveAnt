/**
* Copyright (c) 2017 Razeware LLC
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
* distribute, sublicense, create a derivative work, and/or sell copies of the
* Software in any work that is designed, intended, or marketed for pedagogical or
* instructional purposes related to programming, coding, application development,
* or information technology.  Permission for such use, copying, modification,
* merger, publication, distribution, sublicensing, creation of derivative works,
* or sale is expressly withheld.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

import Foundation
import SpriteKit

class GameOverScene: SKScene
{
//  let won:Bool

    var background:SKSpriteNode?
    var replayButton:SKSpriteNode?
    var palyButton:SKSpriteNode?
    var menuButton:SKSpriteNode?
   // var conutiueButton : SKLabelNode?
    
    override init(size: CGSize)
    {
       super.init(size: size)
    }
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
    
        background = (self.childNode(withName: "background") as! SKSpriteNode)
        replayButton = (self.childNode(withName: "replay") as! SKSpriteNode)
        
        palyButton = (self.childNode(withName: "play") as! SKSpriteNode)
        menuButton = (self.childNode(withName: "menu") as! SKSpriteNode)
     //   conutiueButton = (self.childNode(withName: "continue") as!SKLabelNode)
        
      //fatalError("init(coder:) has not been implemented")
    }
  

    
    
  override func didMove(to view: SKView)
  {
//    let nextButton = SKSpriteNode(imageNamed: "refreshing")
//    nextButton.position = CGPoint(x: frame.width/4, y: frame.height/4)
//    nextButton.zPosition = 50
//    nextButton.name = "next"
//     addChild(nextButton)

//
//     var background: SKSpriteNode
//    if (won)
//    {
//        //Show buttons : replay , next
//
//      background = SKSpriteNode(imageNamed: "YouWin")
//      run(SKAction.playSoundFileNamed("win.wav",
//          waitForCompletion: false))
//    } else
//    {
//      background = SKSpriteNode(imageNamed: "YouLose")
//      run(SKAction.playSoundFileNamed("lose.wav",
//          waitForCompletion: false))
//    }
//
//
//    background.position =
//      CGPoint(x: size.width/2, y: size.height/2)
//    self.addChild(background)

    // More here...
//    let wait = SKAction.wait(forDuration: 3.0)
//    let block = SKAction.run {
//      let myScene = GameScene(size: self.size)
//
//      myScene.scaleMode = self.scaleMode
//      let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
//      self.view?.presentScene(myScene, transition: reveal)
//    }
//    self.run(SKAction.sequence([wait, block]))
  }
    func nextButton()
    {
        //Go to levels scene
        print("Button clicked")
        if let scene = SKScene(fileNamed: "LevelsScene")
        {
            // Set the scale mode to scale to fit the window
            scene.scaleMode = .resizeFill
            scene.scaleMode = scaleMode
            let reveal = SKTransition.doorway(withDuration: 1.5)
            view?.presentScene(scene, transition: reveal)
            
        }
        

        
    }
    func replay()
    {
        //Reload scene.
    }
    
    

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        //
        guard let touch = touches.first else
        {
            return
        }
        
        let touchLocation = touch.location(in: self)
        let node = atPoint(touchLocation)
        if node.name == "continue"
        {
          print("Contiue")
           
        }
        else if node.name == "replay"
        {
            print("replay")
        }
        else if node.name == "menu"
        {
            nextButton()
            print(node.name)
        }
        
    }
}
