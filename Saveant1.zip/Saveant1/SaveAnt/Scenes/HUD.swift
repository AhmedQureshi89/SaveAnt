//
//  HUD.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 21/04/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
 import SpriteKit

 enum HUDSettings
 {
  static let font = "Noteworthy-Bold"
  static let fontSize: CGFloat = 50
}
 
 enum HUDMessages
 {
  static let dragToMakeWater = "drag to deliver water to roses"
  static let tapToStart = "Tap to Start"
  static let win = "You Win!"
  static let lose = "Out of Time!"
  static let nextLevel = "Tap for Next Level"
  static let playAgain = "Tap to Play Again"
  static let reload = "Continue Previous Game?"
  static let yes = "Yes"
  static let no = "No"
    
}

class HUD: SKNode
{
    var pauseButton:SKSpriteNode?
    var timerLabel: SKLabelNode?
  override init() {
    super.init()
    name = "HUD"
    
  }
    
     func add(message: String, position: CGPoint,
             fontSize: CGFloat = HUDSettings.fontSize)
     {
      let label: SKLabelNode
      label = SKLabelNode(fontNamed: HUDSettings.font)
      label.text = message
      label.name = message
      label.zPosition = 100
      addChild(label)
      label.fontSize = fontSize
      label.position = position
    }
    
    func addTimer(time: Int) {
      guard let scene = scene else { return }
      // 1
      let position = CGPoint(x: 0,
                             y: scene.frame.height/2 - 10)
      add(message: "Timer", position: position, fontSize: 24)
      // 2
      timerLabel = childNode(withName: "Timer") as? SKLabelNode
      timerLabel?.verticalAlignmentMode = .top
      timerLabel?.fontName = "Menlo"
     // updateTimer(time: time)
    }
    
     func updateGameState(from: GameState, to: GameState)
     { 
       clearUI(gameState: from)
      updateUI(gameState: to)
    }
    
//    func addPausButton()
//    {
//       guard let scene = scene else { return }
//      // 1
//
//        let position = CGPoint(x: 0,
//                               y: scene.frame.height/4 - 10)
//
////      let position = CGPoint(x: scene.frame.size.width * -0.5 + 30 , y: scene.frame.size.height * -0.5 + 40  )
//
////        CGPoint(x: scene.frame.size.width * -0.5 + 30 , y: scene.frame.size.height * -0.5 + 30  )
//
//      // 2
//        let pause = SKSpriteNode(imageNamed: "pause")
//       pause.name = "pause"
//       pause.position = position
//        pause.zPosition = 100
//        pauseButton = pause
//        addChild(  self.pauseButton!)
//
//    }
//
    private func updateUI(gameState: GameState)
    {
         switch gameState
         {
         case .start:
//          add(message: HUDMessages.tapToStart, position: .zero)
            add(message: HUDMessages.dragToMakeWater, position: CGPoint(x: 0, y: 40))
            let dragIcon = SKSpriteNode(imageNamed: "drag")
            dragIcon.name = "drag"
            dragIcon.position = CGPoint(x: 0, y:150)
            
            addChild(dragIcon)
           // addPausButton()
        case .win:
          add(message: HUDMessages.win, position: .zero)
          add(message: HUDMessages.nextLevel,
              position: CGPoint(x: 0, y: -100))
        case .lose:
          add(message: HUDMessages.lose, position: .zero)
          add(message: HUDMessages.playAgain,
              position: CGPoint(x: 0, y: -100))
            
         case .reload:
            add(message: HUDMessages.reload, position: .zero,
                fontSize: 40)
            add(message: HUDMessages.yes,
                position: CGPoint(x: -140, y: -100))
            add(message: HUDMessages.no,
                position: CGPoint(x: 130, y: -100))
            
             
        default:
          break
        }
    }
      
    private func clearUI(gameState: GameState)
    {
         switch gameState
         {
          case .start:
//           remove(message: HUDMessages.tapToStart)
            remove(message: HUDMessages.dragToMakeWater)
            childNode(withName: "drag")?.removeFromParent()
        case .win:
          remove(message: HUDMessages.win)
          remove(message: HUDMessages.nextLevel)
        case .lose:
          remove(message: HUDMessages.lose)
          remove(message: HUDMessages.playAgain)
             case .reload:
              remove(message: HUDMessages.reload)
              remove(message: HUDMessages.yes)
              remove(message: HUDMessages.no)
        default:
          break
        } 
    }
    
    private func remove(message: String)
    {
        childNode(withName: message)?.removeFromParent()
    }
    
  required init?(coder aDecoder: NSCoder) {
    super.init(coder: aDecoder)
   // pauseButton = childNode(withName: "pause") as! SKSpriteNode
  }
}
