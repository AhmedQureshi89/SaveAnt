//
//  FirstMission.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 03/03/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation
class GS :SKScene
{
    //MARK:- Properties
    var lastUpdateTime: TimeInterval = 0.0
    var dt: TimeInterval = 0.0
    var lastTouchLocation: CGPoint?
    var playerConstraint :SKConstraint!
    var edgeConstraint :SKConstraint!
    var heroAnt = Ant()
    var victemAnt:Ant?
    var leaf:Leaf?
    var target:CGPoint? = CGPoint(x: 100, y: 0)
    let pointer = SKSpriteNode(imageNamed: "arrowUp.png")
    var lookAtConstraint = SKConstraint()
    var numberOfFollow = 0
    var isHeroLost = false
    var enemyNode = Enemy()
    var enemiesNode = SKNode()
    var cul = 7
     var waterCopy = SKTileMapNode()
    var newTileCounter = 0
    var distanceToVictemAnt =  CGFloat()
    var victemAntPosition = CGPoint()
    let distanceRange = 20.0..<40.0
    var palntNode:SKSpriteNode?
    var collectedFoodCount = 0
    var foodCount = 0
     var plants = SKNode()
    //MARK:- MapProperties
    var enemyTileMap:SKTileMapNode?
    var diriction:CGPoint?
    var scenCam:SKCameraNode?
    var backgroundTileMap:SKTileMapNode?
    var waterTileMap:SKTileMapNode?
    var grassTileMap:SKTileMapNode?
    var flowerTileMap:SKTileMapNode?
    var isVictemNear = false
    var pauseButton:SKSpriteNode?
    lazy var itemsButton: StuffAnalogContorller =
        {
             let js = StuffAnalogContorller()
            js.position = CGPoint(x: self.frame.size.width * -0.5 , y: self.frame.size.height * -0.5   )
            js.didMoveToScene()
            return js
    }()
    var foundOne = false
    var testCo = SKSpriteNode(color: .red, size: CGSize(width: 50, height: 50))
    var backButton:SKSpriteNode?
    var addedStuff :Stuff?
    var currentLevel: Int = 1
    
    //MARK:- Init
     override func encode(with aCoder: NSCoder)
     {
      aCoder.encode(foodCount,
                    forKey: "Scene.foodCount")
       
      aCoder.encode(gameState.rawValue,
                    forKey: "Scene.gameState")
      aCoder.encode(currentLevel,
                    forKey: "Scene.currentLevel")
      super.encode(with: aCoder)
    }
    
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        
        backgroundTileMap = (childNode(withName: "background") as! SKTileMapNode)
        grassTileMap = (childNode(withName: "grass") as! SKTileMapNode)
        waterTileMap = (childNode(withName: "water") as!
                            SKTileMapNode)
        
         let savedGameState = aDecoder.decodeInteger(
          forKey: "Scene.gameState")
        if let gameState = GameState(rawValue: savedGameState),
            gameState == .pause
        {
          self.gameState = gameState
          foodCount = aDecoder.decodeInteger(
            forKey: "Scene.foodCount")
 
          currentLevel = aDecoder.decodeInteger(
            forKey: "Scene.currentLevel")
          // 2
            hud = camera!.childNode(withName: "HUD") as! HUD
          heroAnt = childNode(withName: "HeroAnt") as! Ant
  
        }
        
        
        addObservers()
  
    }
   
    
    
    override init(size: CGSize)
    {
        super.init(size: size)
    }
   
    
    var hud = HUD()
    
     var gameState: GameState = .initial
     {
      didSet {
        hud.updateGameState(from: oldValue, to: gameState)
      }
    }
    
    func checkEndGame()
    {
         if foodCount == collectedFoodCount
        {
             gameState = .win
        }
    
//      if bugsNode.children.count == 0
//      {
//        player.physicsBody?.linearDamping = 1
//        gameState = .win
//      }
    }
    
    func transitionToScene(level: Int)
    {
     // 1
        print("Transitioning")
     guard let newScene = SKScene(fileNamed: "Level\(level)")
       as? GS else {
         fatalError("Level: \(level) not found")
     }
     // 2
     newScene.currentLevel = level
     view?.presentScene(newScene,
       transition: SKTransition.flipVertical(withDuration: 0.5))
   }
    
    var backgroundMusicPlayer: AVAudioPlayer!
    
    func playBackgroundMusic(filename: String)
    {
      let resourceUrl = Bundle.main.url(forResource:
        filename, withExtension: nil)
      guard let url = resourceUrl else {
        print("Could not find file: \(filename)")
        return
      }

      do {
        try backgroundMusicPlayer =
          AVAudioPlayer(contentsOf: url)
        backgroundMusicPlayer.numberOfLoops = -1
        backgroundMusicPlayer.prepareToPlay()
        backgroundMusicPlayer.play()
      } catch {
        print("Could not create audio player!")
        return
      }
    }
    
    let antEatingSound: SKAction = SKAction.playSoundFileNamed(
      "ES_Insect Eat Chew 11 - SFX Producer.mp3", waitForCompletion: false)
    let antWalkingSound: SKAction = SKAction.playSoundFileNamed(
      "Insect Walk Tree 2.mp3", waitForCompletion: false)
    
    
    override func didMove(to view: SKView)
    {
        playBackgroundMusic(filename: "ES_Park Wind 1 - SFX Producer.mp3")
//        SKTAudio.sharedInstance().playSoundEffect("ES_Park Wind 1 - SFX Producer.mp3")
        
//         self.setupWorldPhysics()
//        let hero =  Ant()
//         hero.position = CGPoint(x: 0, y:0)
//        hero.name = "Anthero"
//        self.heroAnt = hero
//         addChild( self.heroAnt!)
//
//         lineColor = UIColor.white
//        lineWidth = 10
         let pause = SKSpriteNode(imageNamed: "pause")
        pause.name = "pause"
        self.pauseButton = pause

//
//        let back = SKSpriteNode(imageNamed: "refreshing")
//        back.name = "refresh"
//        back.position = CGPoint(x: size.width/2, y: size.height/4)
//        self.backButton = back
//        addChild(self.backButton!)
//
//         setupCamera()
//        setupWaterPhysics()
//        createEnemies()
//         setupFls()
//
          addPlayPauseButton()
//
//        NotificationCenter.default.addObserver(self, selector: #selector(itemTapped), name: Notification
//            .Name(Stuff.kStuffTappedNotification),object: nil)
//
//        pointer.physicsBody = SKPhysicsBody()
//       scene!.addChild(pointer)
//
//        lookAtConstraint = SKConstraint.orient(to: target!,
//                                              offset: SKRange(constantValue: -CGFloat.pi / 2))
//        if playerConstraint == nil {
//           let zeroDistance = SKRange(constantValue: 0)
//           let playerConstraint =
//               SKConstraint.distance(zeroDistance,
//                                     to: heroAnt!)
//           self.playerConstraint = playerConstraint
//       }
//
//       pointer.zPosition = 80
//       pointer.constraints = [ lookAtConstraint, playerConstraint ]
//        setupHUD()
//        gameState = .start
        
        
          if gameState == .initial
          {
            addChild(heroAnt)
            setupWorldPhysics()
            setupWaterPhysics()
            setupFlowers()
 //            setupObstaclePhysics()
//            if firebugCount > 0 {
//              createBugspray(quantity: firebugCount + 10)
            setupHUD()
            gameState = .start
            }
        
//          }
        setupCameraA()
//          setupCamera()
    }
    
     func setupHUD()
     {
      camera?.addChild(hud)
       // hud.addPausButton()
     }
    
    
    func setupCameraA() {
      guard let camera = camera, let view = view else { return }

      let zeroDistance = SKRange(constantValue: 0)
      let playerConstraint = SKConstraint.distance(zeroDistance,
                                                   to: heroAnt)
      // 1
      let xInset = min(view.bounds.width/2 * camera.xScale,
                       backgroundTileMap!.frame.width/2)
      let yInset = min(view.bounds.height/2 * camera.yScale,
                       backgroundTileMap!.frame.height/2)

      // 2
        let constraintRect = backgroundTileMap!.frame.insetBy(dx: xInset,
                                                    dy: yInset)
      // 3
      let xRange = SKRange(lowerLimit: constraintRect.minX,
                           upperLimit: constraintRect.maxX)
      let yRange = SKRange(lowerLimit: constraintRect.minY,
                           upperLimit: constraintRect.maxY)

      let edgeConstraint = SKConstraint.positionX(xRange, y: yRange)
      edgeConstraint.referenceNode = backgroundTileMap
      // 4
      camera.constraints = [playerConstraint, edgeConstraint]
    }

    
    func setupCamera() {
      guard let camera = camera, let view = view else { return }
      
      let zeroDistance = SKRange(constantValue: 0)
      let playerConstraint = SKConstraint.distance(zeroDistance,
                                                   to: heroAnt)
      // 1
      let xInset = min(view.bounds.width/2 * camera.xScale,
                       backgroundTileMap!.frame.width/2)
      let yInset = min(view.bounds.height/2 * camera.yScale,
                       backgroundTileMap!.frame.height/2)
      
      // 2
        let constraintRect = backgroundTileMap!.frame.insetBy(dx: xInset,
                                                    dy: yInset)
      // 3
      let xRange = SKRange(lowerLimit: constraintRect.minX,
                           upperLimit: constraintRect.maxX)
      let yRange = SKRange(lowerLimit: constraintRect.minY,
                           upperLimit: constraintRect.maxY)
      
      let edgeConstraint = SKConstraint.positionX(xRange, y: yRange)
      edgeConstraint.referenceNode = backgroundTileMap
      // 4
      camera.constraints = [playerConstraint, edgeConstraint]
    }
    
    func setupWorldPhysicsA() {
        backgroundTileMap!.physicsBody =
            SKPhysicsBody(edgeLoopFrom: backgroundTileMap!.frame)

        backgroundTileMap!.physicsBody?.categoryBitMask = PhysicsCategory.Edge
      physicsWorld.contactDelegate = self
    }
    
    
    func addPlayPauseButton()
    {
        self.pauseButton!.zPosition = 50
        self.pauseButton!.position =  CGPoint(x: self.frame.size.width * -0.5 + 30 , y: self.frame.size.height * -0.5 + 40  )
        self.camera?.addChild(pauseButton!)
      }
    
     
    var isWalikingSoundPaused: Bool?
    override func update(_ currentTime: TimeInterval)
    {
         if gameState != .play
         {
          isPaused = true
          return
        }
        checkEndGame()
 
 
//        //Get the differince of frame updates
         dt = currentTime - lastUpdateTime
        lastUpdateTime = currentTime
// 
//        Keep tracking of Hero movment
        enumerateChildNodes(withName: "//HeroAnt", using: { [self]node, stop in
             let antNode = node as! Ant
            
            antNode.move(dt: self.dt)
 
         })
//        //Keep tracking of Leaf movment
//        enumerateChildNodes(withName: "//Leafy", using: {node, stop in
//            let leafNode = node as! Leaf
//            leafNode.move(dt: self.dt)
//        })
//        
//        //Keep tracking of Enemy movment
////        enumerateChildNodes(withName: "//enemy", using: { [self]node, stop in
////            let antNode = node as! Enemy
////            antNode.dt = dt
////
////            if antNode.isOnEdge == true
////            {
////
////                antNode.foundOne = foundOne
////
////                antNode.isOnEdge = false
////
////            }
////
////          else if foundOne == true && numberOfFollow <= 300
////            {
////
////            antNode.addMovingPoint(point: heroAnt!.position)
////                antNode.move(dt: self.dt)
////                numberOfFollow += 1
////
////            if numberOfFollow == 301
////            {
////                foundOne = false
////                isHeroLost = true
////                numberOfFollow = 0
////                antNode.clearWayPoints()
////                antNode.foundOne = foundOne
////             }
////
////
////              }
////
////        })
//          
//        distanceToVictemAnt = heroAnt.position.distanceTo( self.victemAntPosition) as! CGFloat
//        
//        enumerateChildNodes(withName: "//Ant", using: { [self] node, stop in
//            let antNode = node as! Ant
//            antNode.move(dt: self.dt)
//             if distanceRange.contains(Double(distanceToVictemAnt))
//            {
//                isVictemNear = true
////                antNode.isfollowing = true
////
////                print("Victem is close")
//            }
////            if antNode.isfollowing == true
////            {
////                antNode.addMovingPoint(point: heroAnt!.position + CGPoint(x: 0, y: 20))
////                antNode.move(dt: self.dt)
////
////                }
//
//
//        })
////
//        
//
//        
//        
////        if newTileCounter == 450
////        {
////
////            if isWheelClicked == true
////            {  newTileCounter = 0
////                print("REutrning")
////                isWheelClicked = false
////                return
////            }
////            print("line afet return")
////                 for  row in stride(from: 7, through: 40, by: 2)
////                    {
////                        testCo.color = .gray
////                        let node = SKNode()
////                        let tileSet = SKTileSet(named: "Sample Grid Tile Set")!
////
////                        let waterTiles = tileSet.tileGroups.first { $0.name == "Water" }
////
////                   node.physicsBody =
////                       SKPhysicsBody(rectangleOf: CGSize(width:50, height: 50))
//////                    SKPhysicsBody(edgeLoopFrom: CGRect(x: 0, y: 0, width: 400, height: 400))
//////
//////                   node.physicsBody?.isDynamic = false
////                   node.physicsBody?.friction = 0
////
////                   node.physicsBody?.categoryBitMask = PhysicsCategory.Water
////
////                   node.zPosition = 100
////                   node.name = "waterss"
////                        waterTileMap?.setTileGroup(waterTiles, forColumn: cul, row: row)
////                        waterTileMap?.enableAutomapping = true
////                    node.position = waterTileMap!.centerOfTile(
////                       atColumn: cul, row: row)
////                        waterTileMap!.addChild(node)
////                      }
////                 cul += 2
////                 newTileCounter = 0
////
////           }
////        newTileCounter += 1
//        

    }
    
    
    
    override func didSimulatePhysics()
    {
        
    }
    
    func setupCameraB()
    {
        guard let camera = camera else
        { return }
        guard let view = view else { return }
        
        //camera.setScale(0.4)
        // 1
        let xInset = min(view.bounds.width * camera.xScale,
                         backgroundTileMap!.frame.width/2)
        let yInset = min(view.bounds.height/2 * camera.yScale,
                         backgroundTileMap!.frame.height/2)
        
        // 2
        let constraintRect = backgroundTileMap!.frame.insetBy(dx: xInset,
                                                      dy: yInset)
        // 3
//        let xRange = SKRange(lowerLimit: constraintRect.minX    ,
//                             upperLimit: scene!.position.x +  scene!.frame.width * 6)
//        
//        let yRange = SKRange(lowerLimit: constraintRect.minY * 4  ,
//                             upperLimit: scene!.position.x +  scene!.frame.width * 2)
        
        let xRange = SKRange(lowerLimit: constraintRect.minX,
                              upperLimit: constraintRect.maxX)
         let yRange = SKRange(lowerLimit: constraintRect.minY,
                              upperLimit: constraintRect.maxY)
        
        let zeroDistance = SKRange(constantValue: 0)
//        let playerConstraint =
//            SKConstraint.distance(zeroDistance,
//                                  to: heroAnt)
//        self.playerConstraint = playerConstraint
        
        
        let edgeConstraint = SKConstraint.positionX(xRange, y: yRange)
        edgeConstraint.referenceNode = scene
//        self.edgeConstraint = edgeConstraint
        // 4
        camera.constraints = [edgeConstraint]
 
    }
    
    //MARK:- Setup physics
    
    func setupFlowers()
    {
        guard let flowerMap = childNode(withName: "Flowers")
            as? SKTileMapNode else { return }
        // 1
        for row in 0..<flowerMap.numberOfRows
        {
            for column in 0..<flowerMap.numberOfColumns
            {
               
                // 2
                guard let tile = tile(in: flowerMap,
                                      at: (column, row))
                    else { continue }
                // 3
              
                let plant = SKSpriteNode()
                plant.physicsBody =
                    SKPhysicsBody(circleOfRadius: 30, center: CGPoint(x: 30, y: 0))
                     
               
                plant.physicsBody?.isDynamic = true
                plant.physicsBody?.friction = 0
                plant.physicsBody?.categoryBitMask = PhysicsCategory.Plant
 
                plant.physicsBody?.contactTestBitMask = PhysicsCategory.Water
 
                plant.zPosition = 120
                
                
                plant.position = flowerMap.centerOfTile(atColumn: column,
                                                          row: row)
                plants.zPosition = 100
                plants.addChild(plant)
                self.foodCount += 1
             }
        }
        // 4
        plants.name = "plants"
        addChild(plants)
        // 5
        
     }
    
 
    func setupWaterPhysics()
    {
        guard let waterTileMap = waterTileMap else { return }
        // 1
        for row in 0..<waterTileMap.numberOfRows
        {
            for column in 0..<waterTileMap.numberOfColumns
            {
                // 2
                guard let tile = tile(in: waterTileMap,
                                      at: (column, row))
                    else { continue }
                
                let node = SKNode()
                node.physicsBody =
                    SKPhysicsBody(rectangleOf: CGSize(width: tile.size.width/6, height: tile.size.width/6))
                
                 node.physicsBody?.isDynamic = false
                node.physicsBody?.friction = 0

                node.physicsBody?.categoryBitMask = PhysicsCategory.Water
 
                node.zPosition = 100
                node.name = "waters"
                //node.isHidden = true
                 node.position = waterTileMap.centerOfTile(
                    atColumn: column, row: row)
                 waterTileMap.addChild(node)
              }
            
        }
     }
    
    func setupWorldPhysics()
    {
        scene!.physicsBody =
            SKPhysicsBody(edgeLoopFrom: scene!.frame)
        
        scene!.physicsBody?.categoryBitMask = PhysicsCategory.Edge
        physicsWorld.contactDelegate = self
        scene?.setScale(5)
    }
    
    func tile(in tileMap: SKTileMapNode,
              at coordinates: TileCoordinates)
        -> SKTileDefinition?
    {
        return tileMap.tileDefinition(atColumn: coordinates.column,
                                      row: coordinates.row)
    }
    
       
    
    //MARK:- Touch Method
    var touchPoint:CGPoint!
    var startingPoint:CGPoint!
    var lineColor:UIColor!
    var lineWidth:CGFloat!
//    func sceneTouched(touchLocation:CGPoint)
//    {
//         lastTouchLocation = touchLocation
//     }
//
//
//
//    override func touchesBegan(_ touches: Set<UITouch>,
//                               with event: UIEvent?)
//    {
//         guard let touch = touches.first else
//         {
//            return
//        }
//        let touchLocation = touch.location(in: self)
//        sceneTouched(touchLocation: touchLocation)
//
//        let node = atPoint(touchLocation)
//
//
//        if childNode(withName: "Anthero") == nil
//        {
//            leaf?.touchesBegan(touches, with: event)
//        }
//        else {
//            heroAnt?.isSpeeding = false
//            heroAnt?.touchesBegan(touches, with: event)
//
//        }
//
//
//    }
//
//    override func touchesMoved(_ touches: Set<UITouch>,
//                               with event: UIEvent?) {
//        guard let touch = touches.first else {
//            return
//        }
//        let touchLocation = touch.location(in: self)
//
//        sceneTouched(touchLocation: touchLocation)
//
//    }
//
//
//    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
//    {
//
//        guard let touch = touches.first else { return }
////        locationOftheTouch = touch.location(in: self)
//
//        let node = atPoint(touch.location(in: self))
//        print(node.name)
//        if node.name == "appleSeed"
//        {
//            print("La le lu")
//         }
//
//    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        // get the touch position when user starts drawing
        let touch = touches.first
        startingPoint = touch?.location(in: self)
        
                let node = atPoint(startingPoint)
        if node.name == "pause"
        {
 
             gameState = .reload
            SKTAudio.sharedInstance().playSoundEffect("ES_Switch Click 1 - SFX Producer.mp3")
            SKTAudio.sharedInstance().soundEffectPlayer?.pause()
            
//            if let scene = SKScene(fileNamed: "LevelsScene")
//            {
//                 scene.scaleMode = .aspectFill
//
//                 view!.presentScene(scene)
//            }
        }
 
        switch gameState
        {
         // 1
         case .start:
           gameState = .play
           isPaused = false
 
         case .play:
           print("Playing")
        case .win:
          transitionToScene(level: currentLevel + 1)
             case .reload:
              // 1
              if let touchedNode =
                    atPoint(touch!.location(in: self)) as? SKLabelNode {
                // 2
                if touchedNode.name == HUDMessages.yes
                {
                    SKTAudio.sharedInstance().playSoundEffect("mixkit-positive-interface-click-1112.wav")
                  isPaused = false
                   gameState = .play
                  // 3
                } else if touchedNode.name == HUDMessages.no
                {
                    SKTAudio.sharedInstance().playSoundEffect("ES_Switch Click 1 - SFX Producer.mp3")
                    if let scene = SKScene(fileNamed: "LevelsScene")
                    {
                        scene.scaleMode = .aspectFill
                        
                        view!.presentScene(scene)
                    }
                }
              }
              default:
               break
                
        }
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        // get the next touch point as the user draws
        let touch = touches.first
         
        touchPoint = touch?.location(in: self)
        
        let rowInd = waterTileMap?.tileRowIndex(fromPosition: touchPoint)
       
        let colInd = waterTileMap?.tileColumnIndex(fromPosition: touchPoint)
 
        let node = SKNode()
        let tileSet = SKTileSet(named: "Sample Grid Tile Set")!
        
        let waterTiles = tileSet.tileGroups.first { $0.name == "Water" }
        
        node.physicsBody =
            SKPhysicsBody(circleOfRadius: 30)
        
          node.physicsBody?.isDynamic = false
        node.physicsBody?.friction = 0
        
        node.physicsBody?.categoryBitMask = PhysicsCategory.Water
 
        node.zPosition = 100
        node.name = "waterss"
        waterTileMap?.setTileGroup(waterTiles, forColumn: colInd!, row: rowInd!)
        waterTileMap?.enableAutomapping = true
        node.position = waterTileMap!.centerOfTile(
            atColumn: colInd!, row: rowInd!)
        waterTileMap!.addChild(node)
 
    }
 
}




extension GS: SKPhysicsContactDelegate
{
    
    
    func didBegin(_ contact: SKPhysicsContact)
    {
        let other = contact.bodyA.categoryBitMask
            == PhysicsCategory.Ant ?
                contact.bodyB : contact.bodyA
       
        switch other.categoryBitMask
        {
        
        case PhysicsCategory.Water:
            
//            print("contact.bodyA  Water\(contact.bodyA.node?.name )")
            if let ant = contact.bodyA.node as? Ant
            {
                ant.clearWayPoints()
                SKTAudio.sharedInstance().soundEffectPlayer?.pause()
             }
            
            else if let ant = contact.bodyB.node as? Ant
            {
                print("contact.bodyB  Water \(contact.bodyA.node?.name )")
   
             }
            
            //Adding seeds to the scene
        
        case PhysicsCategory.Collectables:
            print("Hit \(contact.bodyA.node?.name) ")
            print("Hit \(contact.bodyB.node?.name) ")
            if let ant = contact.bodyA.node as? Ant
            {
                      //Removing stuff and run eating sound
                
                 if let stuff = contact.bodyB.node as? Stuff
                {
                    SKTAudio.sharedInstance().soundEffectPlayer?.pause()
 
                    stuff.removeFromParent()
                    collectedFoodCount += 1
                     run(antEatingSound)
                 }
                
               }
            
        case PhysicsCategory.Plant :
            if let plant = contact.bodyA.node as? SKSpriteNode
            {
                 plant.physicsBody = nil
                let food = Stuff(imageNamed: "appleSeed")
                food.name = "food"
                food.physicsBody = SKPhysicsBody(circleOfRadius: 45, center: CGPoint(x: 30, y: 0))
                food.physicsBody?.categoryBitMask = PhysicsCategory.Collectables
                
                food.physicsBody?.contactTestBitMask = PhysicsCategory.Ant
 
                food.size = CGSize(width: 80, height: 50)
 
                food.zPosition = 60
                food.position = plant.position + CGPoint(x: 0, y: 20)
               addChild(food)
                
                heroAnt.clearWayPoints()
                heroAnt.addMovingPoint(point: food.position)
                
                     SKTAudio.sharedInstance().playSoundEffect("Insect Walk Tree 2.mp3")

    
                //  playBackgroundMusic(filename: "Insect Walk Tree 2.mp3")
            }
          
            
            
         default:
            break
        }
    }
}

extension GS
{
     func applicationDidBecomeActive()
     {
        if gameState == .pause
        {
          gameState = .reload
        }
      print("* applicationDidBecomeActive")
    }
      
    func applicationWillResignActive()
    {
         if gameState != .lose
         {
          gameState = .pause
        }
        
      print("* applicationWillResignActive")
    }
      
    func applicationDidEnterBackground()
    {
         if gameState != .lose
         {
            saveGame()
        }
      print("* applicationDidEnterBackground")
    }
    
    func addObservers()
    {
      let notificationCenter = NotificationCenter.default
      notificationCenter
        .addObserver(forName: UIApplication.didBecomeActiveNotification,
                     object: nil, queue: nil) { [weak self] _ in
          self?.applicationDidBecomeActive()
      }
      notificationCenter
        .addObserver(forName: UIApplication.willResignActiveNotification,
                     object: nil, queue: nil) { [weak self] _ in
          self?.applicationWillResignActive()
      }
      notificationCenter
        .addObserver(forName: UIApplication.didEnterBackgroundNotification,
                     object: nil, queue: nil) { [weak self] _ in
          self?.applicationDidEnterBackground()
      }
    }
     
}


 // MARK: - Saving Games
extension GS
{
     func saveGame()
     {
      // 1
      let fileManager = FileManager.default
      guard let directory =
        fileManager.urls(for: .libraryDirectory,
                         in: .userDomainMask).first
        else { return }
      // 2
      let saveURL = directory.appendingPathComponent("SavedGames")
      // 3
      do {
        try fileManager.createDirectory(atPath: saveURL.path,
          withIntermediateDirectories: true,
          attributes: nil)
      } catch let error as NSError {
        fatalError(
          "Failed to create directory: \(error.debugDescription)")
      }
      // 4
      let fileURL = saveURL.appendingPathComponent("saved-game")
      print("* Saving: \(fileURL.path)")
         NSKeyedArchiver.archiveRootObject(self, toFile: fileURL.path)
        }
    
    
     class func loadGame() -> SKScene?
     {
      print("* loading game")
      var scene: SKScene?
      // 1
      let fileManager = FileManager.default
      guard let directory =
        fileManager.urls(for: .libraryDirectory,
                         in: .userDomainMask).first
        else { return nil }
      // 2
      let url = directory.appendingPathComponent(
        "SavedGames/saved-game")
      // 3
      if FileManager.default.fileExists(atPath: url.path) {
        scene = NSKeyedUnarchiver.unarchiveObject(
          withFile: url.path) as? GS
        _ = try? fileManager.removeItem(at: url)
      }
      return scene
    }
   
}
