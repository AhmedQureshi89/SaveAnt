//
//  GameState.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 21/04/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
 enum GameState: Int
 {
  case initial=0, start, play, win, lose, reload, pause
}

 
