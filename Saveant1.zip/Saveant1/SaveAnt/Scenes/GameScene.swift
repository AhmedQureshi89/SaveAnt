//
//  GameScene.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 08/12/1441 AH.
//  Copyright © 1441 Ahmed Sabir. All rights reserved.
//

import SpriteKit
import GameplayKit
import AVFoundation
enum NodesZPosition: CGFloat {
    case background, hero, joystick
}
class GameScene: SKScene
{
    
    //TODO: - make subclass of Stuff for Seed only
    //Make subclass for Hero ant
    //Make subclass for Qeen
    //Check locations to navigate to by name befor assigning the location to the constraint
    //Add (x) button for closing stuff menu
    //Add stuff to the camera when user clicks on show menu button
    
    
    //Need to draw more tiles of backgroun in the empty space or just redraw the background in the empty space(Q:Where and how?)
    //MARK:- Properties
    let velocityMultiplier: CGFloat = 0.050
    var leafsNode = SKNode()
    var antNode = SKNode()
     
    var leaf : Leaf?
    var water:SKSpriteNode!
    var ant:Ant!
    var heroAnt:Ant?
    var seed = Stuff()
    var food = Stuff()
    var grassTileMap: SKTileMapNode?
    var background: SKTileMapNode!
    var sandTileMap:SKTileMapNode!
    var waterTileMap: SKTileMapNode!
    var thrownStuff: Stuff?
    var lastUpdateTime: TimeInterval = 0.0
    var dt: TimeInterval = 0.0
    var isSeedTaken = false
    lazy var analogJoystick: AnalogJoystick =
        {
            let js = AnalogJoystick(diameter: 100, colors: nil, images: (substrate: #imageLiteral(resourceName: "jSubstrate"), stick: #imageLiteral(resourceName: "jStick")))
            js.position = CGPoint(x: self.frame.size.width * -0.5 + js.radius + 150, y: self.frame.size.height * -0.5 + js.radius + 150)
            js.zPosition = NodesZPosition.joystick.rawValue
            return js
    }()
    
    lazy var itemsButton: StuffAnalogContorller =
        {
            
            let js = StuffAnalogContorller()
            js.position = CGPoint(x: self.frame.size.width * -0.5 , y: self.frame.size.height * -0.5   )
            js.didMoveToScene()
            return js
    }()
    var stuffAdded :Stuff?
    let pointer = SKSpriteNode(imageNamed: "arrowUp.png")
    var lookAtConstraint = SKConstraint()
    var locationsToNavigate = [CGPoint(x:  -240, y: 80),CGPoint(x:   80, y: 20)]
    let heroAntMovePointsPerSec: CGFloat = 150.0
    var distanceToQueen =  CGFloat()
    var locationOftheTouch = CGPoint()
    let distanceRange = 20.0..<40.0
    
    var lastTouchLocation: CGPoint?
    var playerConstraint :SKConstraint!
    var edgeConstraint :SKConstraint!
    
    let zeroDistance = SKRange(constantValue: 0)
    let distance = SKRange(constantValue: 30)
    var boatCollisionLocation = CGPoint()
    var missionList = [MissionModel]()
     var currentMission = 0
    lazy var missionSvaingAnt = MissionModel(number: 0, msg: "رح انقذ النمله", isAcheived:false , location:CGPoint(x:   80, y: 20), isMissionOnLeaf: true)
    
    lazy  var missionGetPoison = MissionModel(number: 1, msg:  "رح جب السم لان الدبور بهذلنا", isAcheived:false , location:seed.position, isMissionOnLeaf: false)
    
    var isMissionDone = false
 var distanceToTarget = CGFloat()
    var distanceToSafeArea = CGFloat()
    var isOnMission = false
    var nextDiriction = CGPoint()
    var gameOver = false
    var enemyAnt = Enemy()
    var foundOne = false
    var numberOfFollow = 0
    var queenPosition = CGPoint()
    var targetLocation = CGPoint()
    var isHeroLost = false
    var distanceToBase = CGFloat()
    var laser = SKShapeNode()
    var hud = HUD()
     var currentLevel: Int = 1
 
     func transitionToScene(level: Int) {
      // 1
      guard let newScene = SKScene(fileNamed: "Level\(level)")
        as? GameScene else {
          fatalError("Level: \(level) not found")
      }
      // 2
      newScene.currentLevel = level
      view?.presentScene(newScene,
        transition: SKTransition.flipVertical(withDuration: 0.5))
    }
 
     var gameState: GameState = .initial
     {
      didSet {
        hud.updateGameState(from: oldValue, to: gameState)
      }
    }
    
    func checkEndGame()
    {
    
//      if bugsNode.children.count == 0
//      {
//        player.physicsBody?.linearDamping = 1
//        gameState = .win
//      }
    }
    //MARK:- Init
    required init?(coder aDecoder: NSCoder)
    {
        
        super.init(coder: aDecoder)
        background =
            (childNode(withName: "background") as! SKTileMapNode)
        
        grassTileMap = childNode(withName: "grass")
            as? SKTileMapNode
        sandTileMap = childNode(withName: "sands")
            as? SKTileMapNode
        waterTileMap =  background.childNode(withName: "water")
            as? SKTileMapNode
//        ant =  childNode(withName: "ant") as! Ant
        seed =  childNode(withName: "appleSeed") as! Stuff
        food =  childNode(withName: "foodW") as! Stuff
        enumerateChildNodes(withName: "//*", using: { node, _ in
            if let eventListenerNode = node as? EventListenerNode {
                eventListenerNode.didMoveToScene()
            }
        })
    }
    override init(size: CGSize)
    {
        super.init(size: size)
    }
    
    func addPlayPauseButton()
    {
        //self.runAction(sound)
//        self.itemsButton.name = "PAUSE"
        self.itemsButton.zPosition = 3
        self.itemsButton.position =  CGPoint(x: self.frame.size.width * -0.5 + 30 , y: self.frame.size.height * -0.5 + 30  )
//
//            CGPoint(x: self.frame.maxX - itemsButton.frame.width/2 , y: self.frame.maxY - itemsButton.frame.height/2)
        self.camera?.addChild(itemsButton)
//        self.addChild(itemsButton)

    }
 
  
    func isTargetVisibleAtAngle(startPoint: CGPoint, angle: CGFloat, distance: CGFloat) -> Bool
    {
        let lasser = SKShapeNode()
        lasser.lineWidth = 6
        lasser.glowWidth = 8
        lasser.strokeColor = .red
        let rayStart = startPoint
        let rayEnd = CGPoint(x: rayStart.x + distance * cos(angle),
                             y: rayStart.y + distance * sin(angle))
//        self.laser = SKShapeNode()
     
        
         let _ = physicsWorld.enumerateBodies(alongRayStart: rayStart, end: rayEnd) { [self] (body, point, vector, stop) in
            if foundOne == false && body.node!.name == "Anthero"
            {
                print("looking for targets along the ray")
                 foundOne = true
                enemyAnt.foundOne = foundOne
//                 enemyAnt.POINTS_PER_SEC = 150.5
//                enemyAnt.wayPoints.append(heroAnt!.position)
//                enemyAnt.move(dt: dt)
                let p = CGMutablePath()
                      p.move(to: rayStart)
                      p.addLine(to: point)
                      self.laser.path = p
                self.laser.position = enemyAnt.position
//                self.laser.lineLength = p
                laser.lineWidth = 6
                laser.glowWidth = 8
                laser.strokeColor = .red
            
                self.addChild(lasser)
            }
        
        }
        return false
    }
    override func didSimulatePhysics()
    {
        let _ = isTargetVisibleAtAngle(startPoint: enemyAnt.position, angle:   enemyAnt.zRotation + (CGFloat.pi/6) , distance: 300)
        
    }
    
    
    
    override func didMove(to view: SKView)
    {
       
         
        enumerateChildNodes(withName: "QeenAnt") { (node, stop) in
            let antNode = node
            antNode.name = "QeenAnt"
            self.queenPosition = antNode.position
         }
        
        
        let tap = UITapGestureRecognizer(target: self, action:
            #selector(self.handleTapGesture(gesture:)))
        tap.numberOfTapsRequired = 2
        
        self.scene?.view?.addGestureRecognizer(tap)
        
        self.seed.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: (seed.size.width)/2, height: (seed.size.width)/2))
        self.seed.physicsBody?.categoryBitMask = PhysicsCategory.Collectables
        self.seed.haveInstruction = true
        
        self.food.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: (seed.size.width)/2, height: (food.size.width)/2))
        self.food.physicsBody?.categoryBitMask = PhysicsCategory.Collectables
        targetLocation = seed.position
       
        let heroAnt = Ant()
        // heroAnt.didMoveToScene()
        heroAnt.name = "Anthero"
        self.heroAnt = heroAnt
        self.heroAnt?.position = CGPoint(x: -320, y:0)
         setupCamera()
        addChild( self.heroAnt!)
         let enemy = Enemy()
        enemy.name = "enemy"
        self.enemyAnt = enemy
//        self.enemyAnt.zRotation = -.pi / 2
        self.enemyAnt.position = CGPoint(x:  300, y: -200)
        self.enemyAnt.starLocation = self.enemyAnt.position
        addChild(self.enemyAnt)
        self.enemyAnt.moveBug()
//
        
          self.enemyAnt.enemyAreaLocation  = self.enemyAnt.position
        
        setupWorldPhysics()
        // setupGrassPhysics()
        createLeafs()
        setupSandPhysics()
        setupWaterPhysics()
         // setupJoystick()
        createAnts()
        scene!.setScale(0.4)
        NotificationCenter.default.addObserver(self, selector: #selector(itemTapped), name: Notification
            .Name(Stuff.kStuffTappedNotification),object: nil)
  
 
         pointer.physicsBody = SKPhysicsBody()
        scene!.addChild(pointer)
        
        lookAtConstraint = SKConstraint.orient(to: queenPosition,
                                               offset: SKRange(constantValue: -CGFloat.pi / 2))
         if playerConstraint == nil {
            let zeroDistance = SKRange(constantValue: 0)
            let playerConstraint =
                SKConstraint.distance(zeroDistance,
                                      to: heroAnt)
            self.playerConstraint = playerConstraint
        }
 
        pointer.zPosition = 80
        pointer.constraints = [ lookAtConstraint, playerConstraint ]
        
        addPlayPauseButton()

        if ant != nil
        {
            missionSvaingAnt.location = ant.position
            missionList.append(missionSvaingAnt)
            missionList.append(missionGetPoison)
        }
        
        
    }
    
    @objc func handleTapGesture (gesture: UITapGestureRecognizer)
    {
      //  self.heroAnt?.isSpeeding = true
     }
    
    
    func setupCamera()
    {
        guard let camera = camera, let view = view else
        { return }
        
        //camera.setScale(0.4)
        // 1
        let xInset = min(view.bounds.width * camera.xScale,
                         background!.frame.width/2)
        let yInset = min(view.bounds.height/2 * camera.yScale,
                         background!.frame.height/2)
        
        // 2
        let constraintRect = background!.frame.insetBy(dx: xInset,
                                                      dy: yInset)
        // 3
//        let xRange = SKRange(lowerLimit: constraintRect.minX    ,
//                             upperLimit: scene!.position.x +  scene!.frame.width * 6)
//
//        let yRange = SKRange(lowerLimit: constraintRect.minY * 4  ,
//                             upperLimit: scene!.position.x +  scene!.frame.width * 2)
        
        
         let xRange = SKRange(lowerLimit: constraintRect.minX,
                               upperLimit: constraintRect.maxX)
          let yRange = SKRange(lowerLimit: constraintRect.minY,
                               upperLimit: constraintRect.maxY)
           
        let zeroDistance = SKRange(constantValue: 0)
        let playerConstraint =
            SKConstraint.distance(zeroDistance,
                                  to: heroAnt!)
        self.playerConstraint = playerConstraint
        
        
        let edgeConstraint = SKConstraint.positionX(xRange, y: yRange)
        edgeConstraint.referenceNode = background
//        self.edgeConstraint = edgeConstraint
        // 4
        camera.constraints = [self.playerConstraint,edgeConstraint]
//        cmerSetOfNodes = camera.containedNodeSet()
//        for i in cmerSetOfNodes
//        {
//            print(i.name)
//        }
    }
    
    
    @objc func onboardAntWillingly()
    {
        
        if ((leaf?.childNode(withName: "passingerAnt")) != nil)
        {
            leaf?.childNode(withName: "passingerAnt")?.removeFromParent()
            
            let ant = Ant()
            ant.name = "Anthero"
            //            heroAnt?.removeFromParent()
            heroAnt = ant
            heroAnt!.position = CGPoint(x: boatCollisionLocation.x + 10, y: boatCollisionLocation.y + 3)
            addChild(heroAnt!)
            leaf?.hasPassenger = false
            
            if ((leaf?.childNode(withName: "unboardButton")) != nil)
            {
                leaf?.childNode(withName: "unboardButton")?.removeFromParent()
            }
        }
        
    }
    
    @objc func itemTapped(notification:Notification)
    {
        if let name = notification.userInfo?["name"] as?  Stuff
        {
            
            self.stuffAdded = name
            addChild(self.stuffAdded!)
            self.stuffAdded!.position = CGPoint(x: 80, y: 0)
            
        }
        //      let thrownStuff  = Stuff(imageNamed: "")
    }
    
    
     func setupHUD()
     {
      camera?.addChild(hud)
      hud.add(message: "Howdy", position: .zero)
    }
 
    func inGameMessage(text: String)
    {
        
        let message = MessageNode(message: text)
    //    message.position = CGPoint(x: frame.midX, y: frame.midY)
        //        let carier = SKSpriteNode()
        //           carier.size.width = 100
        //           carier.size.height = 100
        //
        //           carier.color = .yellow
        //           carier.addChild(message)
        //           addChild(carier)
        let msgNode = SKSpriteNode(color: .green, size: CGSize(width: 190, height: 90))
        msgNode.zPosition = 100
 
        let scalingFactor = min(msgNode.frame.width / message.frame.width, msgNode.frame.height / message.frame.height)

                // Change the fontSize.
                message.fontSize *= scalingFactor

                // Optionally move the SKLabelNode to the center of the rectangle.
               message.position = CGPoint(x: msgNode.frame.midX, y: msgNode.frame.midY - message.frame.height / 2.0)
                msgNode.run(SKAction.removeFromParentAfterDelay(3.5))
       
        msgNode.position = queenPosition + CGPoint(x: 20, y: 5)
        addChild(msgNode)
  msgNode.addChild(message)
        // Determine the font scaling factor that should let the label text fit in the given rectangle.
       
        
      }
    
  
    //MARK:- Touch Method
    
    func sceneTouched(touchLocation:CGPoint)
    {
         lastTouchLocation = touchLocation
     }
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?)
    {
         guard let touch = touches.first else
         {
            return
        }
        let touchLocation = touch.location(in: self)
        sceneTouched(touchLocation: touchLocation)
        
        let node = atPoint(touchLocation)
 
       
        if childNode(withName: "Anthero") == nil
        {
            leaf?.touchesBegan(touches, with: event)
        }
        else {
             heroAnt?.touchesBegan(touches, with: event)
             
        }
        
        
                switch gameState {
                 // 1
                 case .start:
                   gameState = .play
                   isPaused = false
       //            startTime = nil
       //            elapsedTime = 0
                 // 2
                 case .play:
                   print("Playing")
                case .win:
                  transitionToScene(level: currentLevel + 1) 
                  //  player.move(target: touch.location(in: self))
                     default:
                       break
                        
                }
        
      

         
        
        
    }
    
    override func touchesMoved(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        guard let touch = touches.first else {
            return
        }
        let touchLocation = touch.location(in: self)
        
        sceneTouched(touchLocation: touchLocation)
        
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
        
        guard let touch = touches.first else { return }
        locationOftheTouch = touch.location(in: self)
        
        let node = atPoint(locationOftheTouch)
        
        if node.name == "unboardButton" && leaf?.childNode(withName: "passingerAnt") != nil
        {
            onboardAntWillingly()
            
        }
        
    }
    
 
    override func update(_ currentTime: TimeInterval)
    {
 
         dt = currentTime - lastUpdateTime
        lastUpdateTime = currentTime
        //Moves 8 points each frame on x
        
        enumerateChildNodes(withName: "//Anthero", using: { [self]node, stop in
            let antNode = node as! Ant
            antNode.move(dt: self.dt)
 
         })
//        self.enemyAnt.moveBug(dt: dt)
        
        enumerateChildNodes(withName: "//enemy", using: { [self]node, stop in
            let antNode = node as! Enemy
            antNode.dt = dt
 
            if enemyAnt.isOnEdge == true
            {
 
                enemyAnt.foundOne = foundOne
                
                enemyAnt.isOnEdge = false
 
            }

          else if foundOne == true && numberOfFollow <= 300
            {
 
            antNode.addMovingPoint(point: heroAnt!.position)
                antNode.move(dt: self.dt)
                numberOfFollow += 1
            
            if numberOfFollow == 301
            {
                foundOne = false
                isHeroLost = true
                numberOfFollow = 0
                antNode.clearWayPoints()
                enemyAnt.foundOne = foundOne
             }


              }
 
        })
//        enumerateChildNodes(withName: "//Leafy", using: {node, stop in
//            let leafNode = node as! Leaf
//            leafNode.move(dt: self.dt)
//        })
// 
//        //Heading to Queen : purpos is to give hero dirictions to queen each time
//        distanceToQueen = heroAnt?.position.distanceTo( self.queenPosition) as! CGFloat
// 
//                if distanceRange.contains(Double(distanceToQueen)) && isOnMission == false
//                {
// 
//                    lookAtConstraint = SKConstraint.orient(to:(leaf?.position)!,
//                                                                              offset: SKRange(constantValue: -CGFloat.pi / 2))
//                                       pointer.constraints = [ lookAtConstraint ]
//                    
//                    if let firstNegative = missionList.first(where: { $0.isAcheived == false })
//                    {
//                         nextDiriction = firstNegative.location
//                        inGameMessage(text: firstNegative.msg)
//  
//                        currentMission = firstNegative.number
//                    }
//                   
//                      isOnMission = true
// 
//                }
//        
//        //MARK: - Saving Ant mission :
// 
//         //Get distance between leaf and vict. ant
//        distanceToTarget = leaf?.position.distanceTo(ant!.position)  as! CGFloat
//        
//        if distanceRange.contains(Double(distanceToTarget) ) && ant?.isAntOnBoard == false && isOnMission == true
//        {
//            ant?.removeFromParent()
//            let antSprite = SKSpriteNode(imageNamed: "antH")
//            antSprite.zPosition = 50
//            antSprite.name = "ant"
//            leaf?.hasPassenger = true
//            leaf!.addChild(antSprite)
//       
//            ant?.isAntOnBoard = true
//            //Pointing to safe land place
//            lookAtConstraint = SKConstraint.orient(to:(CGPoint(x: -150, y: 0)),
//                                                                                offset: SKRange(constantValue: -CGFloat.pi / 2))
//                                         pointer.constraints = [ lookAtConstraint ]
//          }
//        
////        Delivering ant to safe land
//        distanceToSafeArea = leaf?.position.distanceTo(CGPoint(x: -150, y: 0))  as! CGFloat
//        if distanceRange.contains(Double(distanceToSafeArea)) && ant?.isSafe == false
//        {
//            
//             ant?.removeFromParent()
//            addChild(ant!)
//            ant?.position = CGPoint(x: -150, y: 0)
//                ant?.isSafe = true
////            pointing back to queen after mission successed
//            lookAtConstraint = SKConstraint.orient(to:queenPosition,
//                                                   offset: SKRange(constantValue: -CGFloat.pi / 2))
//            pointer.constraints = [ lookAtConstraint ]
//              isOnMission = false
//            
//             if let firstNegative = missionList.first(where: { $0.number == currentMission }) {
//                // To tell the boat where to head next (check didBegin)
// 
//                firstNegative.isAcheived = true
//                nextDiriction = queenPosition
//            }
//          }
//        
//        //Track pointer when on leaf or land
//        if leaf?.hasPassenger == false
//        {
//            //Moves the camera relative to Ant if the leaf has no child with the name mentioned above
//            let playerConstraintToArrow = SKConstraint.distance(distance,
//            to: heroAnt!)
//            let playerConstraint =
//                SKConstraint.distance(zeroDistance,
//                                      to: heroAnt!)
//            self.playerConstraint = playerConstraint
//            camera!.constraints![0] = self.playerConstraint
//            camera!.constraints = [self.playerConstraint,edgeConstraint]
//            pointer.constraints = [ lookAtConstraint, playerConstraintToArrow ]
//         }
//        else
//        {
//            
//            let playerConstraint =
//                SKConstraint.distance(zeroDistance,
//                                      to: leaf!)
//             
//            let leafConstraintToArrow = SKConstraint.distance(distance,
//            to: leaf!)
//             
//            self.playerConstraint = playerConstraint
//            camera!.constraints![0] = self.playerConstraint
//            camera!.constraints = [self.playerConstraint,edgeConstraint]
//            pointer.constraints = [ lookAtConstraint, leafConstraintToArrow]
//        }
//        
        
    }
    
    
    //MARK:- Creating scene components
    func createLeafs()
    {
        
        guard let LeafsMap =  childNode(withName: "leafs")
            as? SKTileMapNode else { return }
        // 1
        for row in 0..<LeafsMap.numberOfRows
        {
            for column in 0..<LeafsMap.numberOfColumns
            {
                guard let tile = tile(in: LeafsMap,
                                      at: (column, row))
                    else { continue }
                
                let leaf = Leaf()
                leaf.didMoveToScene()
                leaf.position = LeafsMap.centerOfTile(atColumn: column,
                                                      row: row)
                self.leaf = leaf
                print("Creating leafs\(self.leaf?.position)")
                leafsNode.addChild(self.leaf!)
            }
        }
        // 4
       
        leafsNode.name = "Leafs"
        addChild(leafsNode)
        // 5
        LeafsMap.removeFromParent()
    }
    
    
    func createAnts()
    {
        guard let bugsMap = childNode(withName: "ants")
            as? SKTileMapNode else { return }
        // 1
        for row in 0..<bugsMap.numberOfRows
        {
            for column in 0..<bugsMap.numberOfColumns
            {
                // 2
                guard let tile = tile(in: bugsMap,
                                      at: (column, row))
                    else { continue }
                // 3
                
                let ant = Ant()
                 self.ant = ant
                
                self.ant!.position = bugsMap.centerOfTile(atColumn: column,
                                                          row: row)
                antNode.addChild( self.ant!)
            }
        }
        // 4
        antNode.name = "Ants"
        addChild(antNode)
        // 5
        
        bugsMap.removeFromParent()
        
    }
    
    
    
    
    
    func tile(in tileMap: SKTileMapNode,
              at coordinates: TileCoordinates)
        -> SKTileDefinition?
    {
        return tileMap.tileDefinition(atColumn: coordinates.column,
                                      row: coordinates.row)
    }
    
    //MARK:- JoyStick
    
    func setupJoystick()
    {
                addChild(analogJoystick)
        
        
        analogJoystick.trackingHandler = { [unowned self] data in
            if (self.leaf?.childNode(withName: "Anthero") as? Ant) != nil
            {
                self.leaf!.position = CGPoint(x: self.leaf!.position.x + (data.velocity.x * self.velocityMultiplier),
                                              y: self.leaf!.position.y + (data.velocity.y * self.velocityMultiplier))
                self.leaf!.zRotation = data.angular
                
            }
            else {
                self.heroAnt!.position = CGPoint(x: self.heroAnt!.position.x + (data.velocity.x * self.velocityMultiplier),
                                                 y: self.heroAnt!.position.y + (data.velocity.y * self.velocityMultiplier))
                self.heroAnt!.zRotation = data.angular
                
                self.pointer.position =  CGPoint(x: self.pointer.position.x + (data.velocity.x * self.velocityMultiplier),
                                                 y: self.pointer.position.y + (data.velocity.y * self.velocityMultiplier))
                self.pointer.zRotation = data.angular
                //                let offset = CGPoint(x:self.heroAnt!.position.x - (self.leaf?.position.x)!,
                //                                     y: (self.heroAnt?.position.y)! - (self.leaf?.position.y)!)
                
                
                // print(offset)
                
            }
            
        }
        
    }
    
    //MARK:- Setup physics
    func setupSandPhysics()
    {
        guard let sandTileMap = sandTileMap else { return }
        // 1
        for row in 0..<sandTileMap.numberOfRows
        {
            for column in 0..<sandTileMap.numberOfColumns
            {
                // 2
                guard let tile = tile(in: sandTileMap,
                                      at: (column, row))
                    else { continue }
                
                let node = SKNode()
                node.physicsBody =
                    SKPhysicsBody(rectangleOf: CGSize(width: tile.size.width/2, height: tile.size.width/2))
                
                node.physicsBody?.isDynamic = false
                node.physicsBody?.friction = 0
                node.physicsBody?.categoryBitMask =
                    PhysicsCategory.Sand
                
                node.position = sandTileMap.centerOfTile(
                    atColumn: column, row: row)
                sandTileMap.addChild(node)
                sandTileMap.setScale(5)
                
            }
        }
    }
    
    func setupGrassPhysics()
    {
        guard let grassTileMap = grassTileMap else { return }
        // 1
        for row in 0..<grassTileMap.numberOfRows
        {
            for column in 0..<grassTileMap.numberOfColumns
            {
                // 2
                guard let tile = tile(in: grassTileMap,
                                      at: (column, row))
                    else { continue }
                
                let node = SKNode()
                node.physicsBody = SKPhysicsBody(rectangleOf: CGSize(width: tile.size.width/2, height: tile.size.width/2))
                node.physicsBody?.isDynamic = false
                node.physicsBody?.friction = 0
                node.physicsBody?.categoryBitMask =
                    PhysicsCategory.Grass
                //
                node.position = grassTileMap.centerOfTile(
                    atColumn: column, row: row)
                grassTileMap.addChild(node)
                grassTileMap.setScale(5)
            }
        }
    }
    
    
    func setupWaterPhysics()
    {
        guard let waterTileMap = waterTileMap else { return }
        // 1
        for row in 0..<waterTileMap.numberOfRows
        {
            for column in 0..<waterTileMap.numberOfColumns
            {
                // 2
                guard let tile = tile(in: waterTileMap,
                                      at: (column, row))
                    else { continue }
                
                let node = SKNode()
                node.physicsBody =
                    SKPhysicsBody(rectangleOf: CGSize(width: tile.size.width/15, height: tile.size.width/15))

                node.physicsBody?.isDynamic = false
                node.physicsBody?.friction = 0

                node.physicsBody?.categoryBitMask = PhysicsCategory.Water

//                node.physicsBody?.collisionBitMask = seed.physicsBody!.categoryBitMask
                node.zPosition = 100
                node.name = "waters"
                 node.position = waterTileMap.centerOfTile(
                    atColumn: column, row: row)
                 waterTileMap.addChild(node)
//                waterTileMap.setScale(5)
 //                waterTileMap.zPosition = 60
            }
        }
    }
    
    
    func setupWorldPhysics()
    {
        scene!.physicsBody =
            SKPhysicsBody(edgeLoopFrom: scene!.frame)
        scene!.physicsBody?.categoryBitMask = PhysicsCategory.Edge
        physicsWorld.contactDelegate = self
        scene?.setScale(5)
    }
}






extension GameScene : SKPhysicsContactDelegate
{
    
    func didBegin(_ contact: SKPhysicsContact)
    {
        let other = contact.bodyA.categoryBitMask
            == PhysicsCategory.Leaf ?
                contact.bodyB : contact.bodyA
       
        switch other.categoryBitMask
        {
        case PhysicsCategory.Leaf:
            if let leaf = other.node as? Leaf
            {
                if let ant = contact.bodyB.node as? Ant
                {
                    leaf.removeFromParent()
                }
            }
            if let ant = contact.bodyB.node as? Ant
            {
                print("Ant want to board")
            }
            
        case PhysicsCategory.Sand:
            
            if other.node != nil
            {
                boatCollisionLocation = other.node?.position as! CGPoint
                if let ant =  (contact.bodyB.node as? Ant)
                {
                    
                }
                else  if let leaf = (contact.bodyB.node as? Leaf)
                {
                    leaf.enumerateChildNodes(withName: "*Ant*")
                    {
                        (node, stop) in
                        
                        if let name = node.name, name.contains("passinger")
                        {
                            
                            if leaf.childNode(withName: "unboardButton") == nil
                            {
                                let unboardAntNode =  SKSpriteNode(imageNamed: "jStick")
                                unboardAntNode.name = "unboardButton"
                                unboardAntNode.zPosition = 50
                                unboardAntNode.position =  CGPoint(x: leaf.frame.size.width * -0.5 +  150, y: leaf.frame.size.height * -0.5  + 50)
                                leaf.addChild(unboardAntNode)
                                
                                
                                let leafConstraint =
                                    SKConstraint.distance(self.zeroDistance,
                                                          to: leaf)
                                unboardAntNode.constraints?.append(leafConstraint)
                                let hideAfterAwhile =    SKAction.afterDelay(5, performAction: SKAction.removeFromParent())
                                
                                unboardAntNode.run(hideAfterAwhile)
                                
                            }
                            
                        }
                        else {
                            //What does this code do?
                            //unboard when hiitting the snad
                            
                            node.removeFromParent()
                            node.position.offset(dx: (other.node?.position.x)!, dy: (other.node?.position.y)!  )
                            
                            node.setScale(0.60)
                            self.addChild(node)
                        }
                    }
                }
            }
            //Add the ant to the leaf
         case PhysicsCategory.Ant :
 
             if let ant = other.node as? Ant
            {

                self.inGameMessage(text:"اتبع السهم ")
                ant.removeFromParent()

                let antSprite = SKSpriteNode(imageNamed: "antH")
                antSprite.zPosition = 50
                antSprite.name = "passingerAnt"
                leaf?.hasPassenger = true
                leaf!.addChild(antSprite)
                 lookAtConstraint = SKConstraint.orient(to:nextDiriction,
                                                       offset: SKRange(constantValue: -CGFloat.pi / 2))
                pointer.constraints = [ lookAtConstraint ]
            }
            
            
        case PhysicsCategory.Collectables :
            if let  stuff = other.node as? Stuff
            {
                if stuff.haveInstruction == true
                {
                    self.inGameMessage(text: "وصل البذرة للشجرة اخر الغابة")
                    stuff.isTaken = true
                    stuff.haveInstruction = false
                    SingletonClass.sharedInstance.stuffArry.append( stuff)
                    stuff.removeFromParent()
                    locationsToNavigate.remove(at: 0)
                     lookAtConstraint = SKConstraint.orient(to:queenPosition,
                                                           offset: SKRange(constantValue: -CGFloat.pi / 2))
                    pointer.constraints = [ lookAtConstraint ]
                    
                }
                else
                {
                    stuff.isTaken = true
                    SingletonClass.sharedInstance.stuffArry.append(stuff)
                    stuff.removeFromParent()
                 }
            }
        case PhysicsCategory.Water :
//            //Game Over , restart game.
            gameOver = true
            print(" Wat Y.bodyA.node?.name \( contact.bodyA.node?.name )")
            print("WAt contact.bodyB.node?.name \(contact.bodyB.node?.name)")
            if let  enemy = contact.bodyB.node as? Enemy
            {
                
                //Bck to rotin
                enemy.clearWayPoints()
                print("Setting is on edge and foune one")
                enemy.isOnEdge = true
                foundOne = false
               
            }
         
//            gameOver = true
//            let gameOverScene = GameOverScene(size: size, won: false)
//            gameOverScene.scaleMode = scaleMode
            // 2
//            let reveal = SKTransition.flipHorizontal(withDuration: 0.5)
            // 3
//            view?.presentScene(gameOverScene, transition: reveal)
//        case PhysicsCategory.Enemy :
//            print("contact.bodyA.node?.name \( contact.bodyA.node?.name )")
//            print("contact.bodyB.node?.name \(contact.bodyB.node?.name)")
        default:
            break
        }
        
    }
    
}

class GlobalVar
{
    static let gv = GlobalVar()
    var leafLoction = CGPoint()
    var wonLevelNumber = Int()
}
