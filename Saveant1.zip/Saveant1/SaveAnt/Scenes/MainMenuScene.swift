/**
* Copyright (c) 2017 Razeware LLC
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Notwithstanding the foregoing, you may not use, copy, modify, merge, publish,
* distribute, sublicense, create a derivative work, and/or sell copies of the
* Software in any work that is designed, intended, or marketed for pedagogical or
* instructional purposes related to programming, coding, application development,
* or information technology.  Permission for such use, copying, modification,
* merger, publication, distribution, sublicensing, creation of derivative works,
* or sale is expressly withheld.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*/

import Foundation
import SpriteKit
import AVFoundation

class MainMenuScene: SKScene
{
    
    var playButton : SKShapeNode?
    var settingsButton : SKShapeNode?
    var  background : SKTileMapNode?
    var menu:SKSpriteNode?
//    var menu2:SKSpriteNode?
     var playLine:SKSpriteNode?
//    var settingsLine:SKSpriteNode?
    var optionPlayPosition :CGPoint?
    var optionSettingsPosition :CGPoint?
    var backgroundMusicPlayer: AVAudioPlayer!
    let clickPlaySound: SKAction = SKAction.playSoundFileNamed(
      "ES_Switch Click 1 - SFX Producer.mp3", waitForCompletion: false)
    required init?(coder aDecoder: NSCoder)
    {
        
        super.init(coder: aDecoder)
        print("Inside init")
        background =
            (childNode(withName: "background") as! SKTileMapNode)
        //playLine = childNode(withName:"playLine") as! SKSpriteNode
        //settingsLine = childNode(withName:"settingsLine") as! SKSpriteNode
//        playButton = (childNode(withName: "playButton") as! SKShapeNode)
       
        menu = (childNode(withName: "menu")as! SKSpriteNode)
        optionPlayPosition = menu?.position
//        menu2 = (childNode(withName: "menu2")as! SKSpriteNode)
//
//        grassTileMap = childNode(withName: "grass")
//            as? SKTileMapNode
//        sandTileMap = childNode(withName: "sands")
//            as? SKTileMapNode
//        waterTileMap =  background.childNode(withName: "water")
//            as? SKTileMapNode
////        ant =  childNode(withName: "ant") as! Ant
//        seed =  childNode(withName: "appleSeed") as! Stuff
//        food =  childNode(withName: "foodW") as! Stuff
//        enumerateChildNodes(withName: "//*", using: { node, _ in
//            if let eventListenerNode = node as? EventListenerNode {
//                eventListenerNode.didMoveToScene()
//            }
//        })
    }
    override init(size: CGSize)
    {
        super.init(size: size)
        print("size of main Scene \(size.height)")
    }

  override func didMove(to view: SKView)
  {
    print("size of main Scene \(size.height)")
   
    
    let wait = SKAction.wait(forDuration: 0.25)
    let addStartNodeAction = SKAction.removeFromParentAfterDelay(3.1)
    let startNode = SKSpriteNode()
    startNode.color = .black
    startNode.size = CGSize(width: frame.size.width, height:  frame.size.height)
    startNode.position = .zero
    startNode.zPosition = 200
    addChild(startNode)
    let antFace = SKSpriteNode(imageNamed: "AntFace2")
    startNode.addChild(antFace)
    antFace.position = .zero
    antFace.zPosition = 200
    startNode.run(addStartNodeAction)
//    let removeStartNode = startNode.run(addStartNodeAction)
//   let sequence = SKAction.sequence(
//      [wait,removeStartNode])
    
//    startNode.run(removeStartNode)
 //create node that will be removed after 3 secs
    //The view have the favce of the icon.
    playBackgroundMusic(filename: "ES_Park Wind 1 - SFX Producer.mp3")

     let shape = SKShapeNode()
    shape.name = "play"

    shape.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width:(menu?.frame.width)!, height: menu!.frame.height), cornerRadius: 64).cgPath
    shape.position = CGPoint(x: menu!.frame.midX, y: menu!.frame.midY)
//    shape.fillColor = UIColor.white
    shape.strokeColor = UIColor.white
    shape.lineWidth = 10
    
    let playLabel = SKLabelNode(text: "Play")
    
    playLabel.fontSize = 40
    playLabel.fontName = "AvenirNext-Regular"
    playLabel.position = CGPoint(x: shape.frame.midX, y: shape.frame.midY - playLabel.frame.height / 2.0)
    playLabel.zPosition = 60
    addChild(playLabel)
    self.playButton?.name = "play"
    self.playButton = shape
    addChild( self.playButton!)
    
    
//    let shapeSettings = SKShapeNode()
//    shapeSettings.name = "settings"
//    shapeSettings.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width: (menu2?.frame.width)!, height: (menu2?.frame.height)!), cornerRadius: 64).cgPath
////    optionSettingsPosition
//    shapeSettings.position = CGPoint(x: menu2!.frame.midX, y: menu2!.frame.midY)
////    shape.fillColor = UIColor.white
//    shapeSettings.strokeColor = UIColor.white
//    shapeSettings.lineWidth = 10
//
//    let settingsLabel = SKLabelNode(text: "Settings")
//    settingsLabel.fontName = "AvenirNext-Regular"
//    settingsLabel.position = CGPoint(x: shapeSettings.frame.midX, y: shapeSettings.frame.midY - playLabel.frame.height / 2.0)
//    settingsLabel.zPosition = 60
//    addChild(settingsLabel)
//    self.settingsButton = shapeSettings
//    addChild(self.settingsButton!)
    menu?.removeFromParent()
//    menu2?.removeFromParent()
 
  }
    func playBackgroundMusic(filename: String)
    {
      let resourceUrl = Bundle.main.url(forResource:
        filename, withExtension: nil)
      guard let url = resourceUrl else {
        print("Could not find file: \(filename)")
        return
      }

      do {
        try backgroundMusicPlayer =
          AVAudioPlayer(contentsOf: url)
        backgroundMusicPlayer.numberOfLoops = -1
        backgroundMusicPlayer.prepareToPlay()
        backgroundMusicPlayer.play()
      } catch {
        print("Could not create audio player!")
        return
      }
    }
    
    
    
    
    func presentScene()
    {
        var factor = view!.frame.size.height / GameConfiguration.Core.gameHeight

        if view!.frame.size.width / factor < GameConfiguration.Core.gameWidth {
            factor = view!.frame.size.width / GameConfiguration.Core.gameWidth
         }

        let sceneSize = CGSize(width: view!.frame.size.width / factor,
                               height: view!.frame.size.height / factor)
         let scene = LevelsScene(size: sceneSize)
         scene.scaleMode = .aspectFit

        view!.presentScene(scene)
     }
    
  func sceneTapped()
  {
     let scene = SKScene(fileNamed: "LevelsScene")
    
      // Set the scale mode to scale to fit the window
    scene!.scaleMode = .aspectFill
//    scene!.scaleMode = scaleMode
        let reveal = SKTransition.doorway(withDuration: 1.5)
    view?.presentScene(scene)
//    view?.presentScene(scene!, transition: reveal)
      // Present the scene
       
    
//    let myScene = FirstMission(size: size)
   
  }

  override func touchesBegan(_ touches: Set<UITouch>,
                             with event: UIEvent?)
  {
    guard let touch = touches.first else
             {
                return
            }
    let touchLocation = touch.location(in: self)
 
           let node = atPoint(touchLocation)
    
    if node.name == "play" {
        run(clickPlaySound)
        self.sceneTapped()
    } else if node.name == "settings" {
        print("Open settings")
    }
    
  }

}
