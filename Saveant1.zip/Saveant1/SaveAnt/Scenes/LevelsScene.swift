//
//  LevelsScene.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 05/04/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit


enum GameConfiguration {
    enum Core {
        static let gameWidth: CGFloat = 960
        static let gameHeight: CGFloat = 540
    }
}
class LevelsScene: SKScene
{
    var levelHolder: SKNode?
    var backButton:SKSpriteNode?
    
    required init?(coder aDecoder: NSCoder)
    {
        super.init(coder: aDecoder)
        levelHolder = childNode(withName: "gridHolder") as! SKNode
    }
    
    override init(size: CGSize)
    {
        super.init(size: size)
      
    }
    
    
    override func didMove(to view: SKView)
    {
        print("size of level Scene \(size.height)")
 
    }
    
    var chessBoard:SKNode?
    var colomunCounter = 6
    var countColr = 5
    var accumulateColomuns = 0
    
    func drawBoard()
    {
        // Board parameters
        let numRows = 6
        var numCols = 6
        let squareSize = CGSize(width: 200, height: 200)
        let xOffset:CGFloat = self.frame.width/7
        let yOffset:CGFloat =  self.frame.height/9
        // Column characters
        //           let alphas:String = "level"
        // Used to alternate between white and black squares
        var toggle:Bool = false
        for row in 0...numRows-1
        {
            
            for coll in stride(from: colomunCounter, through: 1, by: -1)
            {
                //                colomunCounter -= 6
                // Letter for this column
                //                   let colChar = Array(alphas)[col]
                // Determine the color of square
                //                countColr += 5
                let color = toggle ? SKColor.white : SKColor.black
                let square = SKSpriteNode(color: .clear, size: squareSize)
                square.position = CGPoint(x: CGFloat(coll) * squareSize.width + xOffset  ,
                                          y: CGFloat(row) * squareSize.height + yOffset)
                // Set sprite's name (e.g., a8, c5, d1)
                
                
                if row == 5 && coll <= 6
                {
                    square.name = "\(coll)"
                    
                }
                else
                {
                    print("Filling just squares")
                    let shape = SKShapeNode()
                    shape.name = square.name
                    shape.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width:(square.frame.width), height: square.frame.height), cornerRadius: 64).cgPath
                    shape.position = CGPoint(x: square.frame.midX, y: square.frame.midY)
                    shape.fillColor = UIColor.green
                    shape.strokeColor = UIColor.white
                    shape.lineWidth = 10
                    
                    let seed = SKSpriteNode(imageNamed: "almondColored")
                    seed.position = CGPoint.zero
                    shape.addChild(seed)
                    self.addChild(shape)
                    shape.alpha = 0.4
                    
                }
                
                addChild(square)
                //                toggle = !toggle
            }
            
            //               toggle = !toggle
        }
    }
    
    func drawLevelsSqures()
    {
        let xOffset:CGFloat = self.frame.width/7
        let yOffset:CGFloat =  self.frame.height/9
        levelHolder!.enumerateChildNodes(withName: "level")
        { [self] (node, stop) in
            
            let shape = SKShapeNode()
            shape.name = node.name
            shape.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width:(node.frame.width), height: node.frame.height), cornerRadius: 64).cgPath
            shape.position = CGPoint(x: node.frame.size.width + xOffset , y: node.frame.size.height + yOffset)
            shape.fillColor = UIColor.green
            shape.strokeColor = UIColor.white
            shape.lineWidth = 10
            self.addChild(shape)
        }
        
    }
    
    func settingLevelSquareProperties()
    {
        for i in 0...36
        {
            enumerateChildNodes(withName: "\(i)") { (node, stop) in
                //            node.alpha = 0.4
                if let number = node.name
                {
                    let shape = SKShapeNode()
                    shape.name = node.name
                    shape.path = UIBezierPath(roundedRect: CGRect(x: -128, y: -128, width:(node.frame.width), height: node.frame.height), cornerRadius: 64).cgPath
                    shape.position = CGPoint(x: node.frame.midX, y: node.frame.midY)
                    shape.fillColor = UIColor.green
                    shape.strokeColor = UIColor.white
                    shape.lineWidth = 10
                    
                    let levelNumber = SKLabelNode(text: number)
                    levelNumber.fontColor = .red
                    levelNumber.position = CGPoint(x: shape.frame.midX, y: shape.frame.midY )
                    levelNumber.fontSize = 80
                    
                    let seed = SKSpriteNode(imageNamed: "almondColored")
                    seed.position = CGPoint.zero
                    shape.addChild(seed)
                    
                    self.addChild(shape)
                    self.addChild(levelNumber)
                }
                
            }
        }
        
    }
    
    
    func presentScene()
    {
        var factor = view!.frame.size.height / GameConfiguration.Core.gameHeight

        if view!.frame.size.width / factor < GameConfiguration.Core.gameWidth {
            factor = view!.frame.size.width / GameConfiguration.Core.gameWidth
         }

        let sceneSize = CGSize(width: view!.frame.size.width / factor,
                               height: view!.frame.size.height / factor)
         let scene = LevelsScene(size: sceneSize)
         scene.scaleMode = .aspectFit

        view!.presentScene(scene)
     }
    
    func transitionToScene(level: Int)
    {
     // 1
        print("Transitioning")
     guard let newScene = SKScene(fileNamed: "Level\(level)")
       as? GS else {
         fatalError("Level: \(level) not found")
     }
     // 2
     newScene.currentLevel = level
     view?.presentScene(newScene,
       transition: SKTransition.flipVertical(withDuration: 0.5))
   }
    
    func sceneTapped()
    {
        if let scene = SKScene(fileNamed: "FirstMission")
        {
            // Set the scale mode to scale to fit the window
            scene.scaleMode = .resizeFill
            scene.scaleMode = scaleMode
            let reveal = SKTransition.doorway(withDuration: 1.5)
            view?.presentScene(scene, transition: reveal)
            
        }
        
        // Present the scene
        //    let myScene = FirstMission(size: size)
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?)
    {
 
        guard let touch = touches.first else
        {
            return
        }
        
        let touchLocation = touch.location(in: self)
        
        let node = atPoint(touchLocation)
        
        if let nodeName = node.name {
            if nodeName == "backToMenu"
            {
                SKTAudio.sharedInstance().playSoundEffect("ES_Switch Click 1 - SFX Producer.mp3")
                guard let newScene = SKScene(fileNamed:"MainMenuScene")
                   as? MainMenuScene else
                {
                    fatalError("Level: \(nodeName) not found")
                }
                newScene.scaleMode = .aspectFill
                view?.presentScene(newScene)
//                  view?.presentScene(newScene,
//                  transition: SKTransition.flipVertical(withDuration: 0.5))
                
            } else if nodeName.contains("Level") {
                SKTAudio.sharedInstance().playSoundEffect("mixkit-positive-interface-click-1112.wav")
                guard let newScene = SKScene(fileNamed:nodeName)
                  as? GS else {
                    fatalError("Level: \(nodeName) not found")
                }
                // 2
        //        newScene.currentLevel = level
               // newScene.scaleMode = .aspectFill
                newScene.scaleMode = .resizeFill
//                newScene.scaleMode = scaleMode
                view?.presentScene(newScene)
//                view?.presentScene(newScene, transition: SKTransition.)
//                view?.presentScene(newScene,
//                  transition: SKTransition.flipVertical(withDuration: 0.5))
            }
          
        }
        
//        
//        if node.name == "level1"
//        {
////            let seed =  node.childNode(withName: "seed")
////
////             let coloredSeed = SKSpriteNode(imageNamed: "almondColored")
////            coloredSeed.position = seed!.position
////            node.addChild(coloredSeed)
////
////            seed?.removeFromParent()
//            
//            self.sceneTapped()
//        }
//        else if node.name == "refresh"
//        {
//            if let scene = SKScene(fileNamed: "MainMenuScene")
//            {
//                scene.scaleMode = .resizeFill
//                scene.scaleMode = scaleMode
//                let reveal = SKTransition.doorway(withDuration: 1.5)
//                view?.presentScene(scene, transition: reveal)
//            }
//            
//            
//            
//            // Set the scale mode to scale to fit the window
//        }
        
    }
}
