//
//  Types.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 17/12/1441 AH.
//  Copyright © 1441 Ahmed Sabir. All rights reserved.
//

import Foundation
import SpriteKit
protocol EventListenerNode {
  func didMoveToScene()
}

protocol InteractiveNode
{
  func interact()
}

typealias TileCoordinates = (column: Int, row: Int)
 enum Direction: Int
 {
  case forward = 0, backward, left, right
}

/// Used to assign masks to sprite objects

  struct PhysicsCategory
  {
   static let None:      UInt32 = 0
   static let All:       UInt32 = 0xFFFFFFFF
   static let Edge:      UInt32 = 0b1
   static let Ant:    UInt32 = 0b10
   static let Leaf:       UInt32 = 0b100
   static let Sand:   UInt32 = 0b1000
   static let Grass: UInt32 = 0b10000
   static let Collectables: UInt32 = 0b100000
    static let Water: UInt32 = 0b100010
    static let Enemy:UInt32 = 0b101
    static let Plant : UInt32 = 0b1110
    
 }
