//
//  MissionModel.swift
//  SaveAnt
//
//  Created by Ahmed Sabir on 15/02/1442 AH.
//  Copyright © 1442 Ahmed Sabir. All rights reserved.
//

import Foundation
import UIKit
class MissionModel
{
    var number: Int
    var  msg:String
    var isAcheived: Bool
    var location : CGPoint
    var isMissionOnLeaf : Bool
    init(number:Int,msg:String,isAcheived:Bool,location : CGPoint,isMissionOnLeaf:Bool)
    {
        self.number = number
        self.msg = msg
        self.isAcheived = isAcheived
        self.location = location
        self.isMissionOnLeaf = isMissionOnLeaf
    }
}
